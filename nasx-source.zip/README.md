# nasx-source

自托管 NAS 控制面板，支持图标跳转、登录、状态、通知等功能。