#!/bin/bash
echo '通知：系统状态异常'