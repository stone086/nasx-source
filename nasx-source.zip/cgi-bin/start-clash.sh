#!/bin/bash
echo '启动 Clash'