#!/bin/bash
echo 'Clash 状态：运行中'