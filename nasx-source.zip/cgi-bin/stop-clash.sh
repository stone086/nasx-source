#!/bin/bash
echo '停止 Clash'